<?php 

defined('_JEXEC') or die;

$doc->addStylesheet($template_folder.'/css/lib/font-awesome.min.css','text/css');
$doc->addStylesheet($template_folder.'/css/lib/magnific-popup.css','text/css');
$doc->addStylesheet($template_folder.'/css/lib/bxslider.css','text/css');
$doc->addStylesheet($template_folder.'/css/lib/owl.carousel.css','text/css');
$doc->addStylesheet($template_folder.'/css/lib/owl.theme.css','text/css');
$doc->addStylesheet($template_folder.'/css/lib/base.css','text/css');

$doc->addStylesheet($template_folder.'/css/style.css','text/css');
$doc->addStylesheet($template_folder.'/css/blog.css','text/css');

?>