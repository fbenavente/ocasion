<?php 
defined('_JEXEC') or die;

	require_once dirname(__FILE__).'/sub/'.$layoutstyle.'.php';
?>