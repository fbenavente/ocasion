<?php 

defined('_JEXEC') or die;

?>
<!-- Bootstrap CSS -->
<link href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/jquery.bootstrapvalidator/0.5.2/css/bootstrapValidator.min.css"/>
<link rel="stylesheet" href="<?php echo $template_folder; ?>/css/flexslider.css">
<link rel="stylesheet" href="<?php echo $template_folder; ?>/business_assets/css/styles.css">
<link rel="stylesheet" href="<?php echo $template_folder; ?>/css/animate.css">
<link rel="stylesheet" href="<?php echo $template_folder; ?>/business_assets/css/rest.css">
<link rel="stylesheet" href="<?php echo $template_folder; ?>/business_assets/icons/style.css">
<!--<link rel="stylesheet" href="<?php echo $template_folder; ?>/resume_assets/css/strip.css"> -->
<link rel="stylesheet" href="<?php echo $template_folder; ?>/business_assets/css/menu.css">
<!-- Modernizr link js -->
<script src="http://cdnjs.cloudflare.com/ajax/libs/modernizr/2.8.3/modernizr.min.js"></script>